'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

export default function ForumTopics({ params }) {
  const { id } = params
  const [forum, setForum] = useState(null)
  const [topics, setTopics] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [sortOption, setSortOption] = useState('latest')
  
  // Mock data for forum (would be fetched from API)
  const mockForum = {
    id: '2',
    name: 'FGC Buni-Yadi Alumni Forum',
    description: 'Discussion forum for Federal Government College, Buni-Yadi alumni',
    schoolId: {
      id: '1',
      name: 'Federal Government College, Buni-Yadi',
      shortName: 'FGC Buni-Yadi',
      location: {
        city: 'Buni-Yadi',
        state: 'Yobe'
      }
    },
    isGeneral: false,
    topics: 87,
    posts: 542,
    lastActivity: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
    moderators: [
      {
        id: '101',
        firstName: 'Ahmed',
        lastName: 'Ibrahim',
        email: 'ahmed.ibrahim@example.com',
        profilePicture: 'https://randomuser.me/api/portraits/men/1.jpg'
      },
      {
        id: '102',
        firstName: 'Fatima',
        lastName: 'Mohammed',
        email: 'fatima.mohammed@example.com',
        profilePicture: 'https://randomuser.me/api/portraits/women/2.jpg'
      }
    ]
  }
  
  // Mock data for topics (would be fetched from API)
  const mockTopics = [
    {
      id: '1',
      title: 'Welcome to the FGC Buni-Yadi Alumni Forum',
      forumId: '2',
      userId: {
        id: '101',
        firstName: 'Ahmed',
        lastName: 'Ibrahim',
        profilePicture: 'https://randomuser.me/api/portraits/men/1.jpg'
      },
      views: 1250,
      replies: 42,
      isPinned: true,
      isLocked: false,
      lastPostAt: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
      lastPostUserId: {
        id: '103',
        firstName: 'John',
        lastName: 'Okafor'
      },
      createdAt: new Date(Date.now() - 2592000000).toISOString() // 30 days ago
    },
    {
      id: '2',
      title: 'Upcoming Alumni Reunion - July 2025',
      forumId: '2',
      userId: {
        id: '102',
        firstName: 'Fatima',
        lastName: 'Mohammed',
        profilePicture: 'https://randomuser.me/api/portraits/women/2.jpg'
      },
      views: 980,
      replies: 65,
      isPinned: true,
      isLocked: false,
      lastPostAt: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
      lastPostUserId: {
        id: '104',
        firstName: 'Amina',
        lastName: 'Yusuf'
      },
      createdAt: new Date(Date.now() - 1209600000).toISOString() // 14 days ago
    },
    {
      id: '3',
      title: 'School Building Renovation Project',
      forumId: '2',
      userId: {
        id: '103',
        firstName: 'John',
        lastName: 'Okafor',
        profilePicture: 'https://randomuser.me/api/portraits/men/3.jpg'
      },
      views: 756,
      replies: 38,
      isPinned: false,
      isLocked: false,
      lastPostAt: new Date(Date.now() - 7200000).toISOString(), // 2 hours ago
      lastPostUserId: {
        id: '101',
        firstName: 'Ahmed',
        lastName: 'Ibrahim'
      },
      createdAt: new Date(Date.now() - 864000000).toISOString() // 10 days ago
    },
    {
      id: '4',
      title: 'Career Mentorship Program for Current Students',
      forumId: '2',
      userId: {
        id: '104',
        firstName: 'Amina',
        lastName: 'Yusuf',
        profilePicture: 'https://randomuser.me/api/portraits/women/4.jpg'
      },
      views: 542,
      replies: 27,
      isPinned: false,
      isLocked: false,
      lastPostAt: new Date(Date.now() - 43200000).toISOString(), // 12 hours ago
      lastPostUserId: {
        id: '105',
        firstName: 'Emmanuel',
        lastName: 'Adebayo'
      },
      createdAt: new Date(Date.now() - 604800000).toISOString() // 7 days ago
    },
    {
      id: '5',
      title: 'Share Your Success Stories',
      forumId: '2',
      userId: {
        id: '105',
        firstName: 'Emmanuel',
        lastName: 'Adebayo',
        profilePicture: 'https://randomuser.me/api/portraits/men/5.jpg'
      },
      views: 423,
      replies: 19,
      isPinned: false,
      isLocked: false,
      lastPostAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
      lastPostUserId: {
        id: '102',
        firstName: 'Fatima',
        lastName: 'Mohammed'
      },
      createdAt: new Date(Date.now() - 432000000).toISOString() // 5 days ago
    }
  ]
  
  useEffect(() => {
    // Simulate API call to fetch forum details
    const fetchForumDetails = async () => {
      try {
        setLoading(true)
        
        // This would be replaced with actual API call
        // const response = await fetch(`/api/forums/${id}`)
        // const data = await response.json()
        // setForum(data.forum)
        
        // Using mock data for now
        await new Promise(resolve => setTimeout(resolve, 1000))
        setForum(mockForum)
      } catch (err) {
        console.error('Error fetching forum details:', err)
        setError('Failed to load forum details. Please try again later.')
      } finally {
        setLoading(false)
      }
    }
    
    fetchForumDetails()
  }, [id])
  
  useEffect(() => {
    // Simulate API call to fetch topics
    const fetchTopics = async () => {
      try {
        setLoading(true)
        
        // This would be replaced with actual API call
        // const response = await fetch(`/api/topics/forum/${id}?page=${currentPage}&sort=${sortOption}`)
        // const data = await response.json()
        // setTopics(data.topics)
        // setTotalPages(data.totalPages)
        
        // Using mock data for now
        await new Promise(resolve => setTimeout(resolve, 500))
        
        // Sort mock topics based on sort option
        let sortedTopics = [...mockTopics]
        
        if (sortOption === 'latest') {
          sortedTopics.sort((a, b) => {
            if (a.isPinned !== b.isPinned) return b.isPinned ? 1 : -1
            return new Date(b.lastPostAt) - new Date(a.lastPostAt)
          })
        } else if (sortOption === 'newest') {
          sortedTopics.sort((a, b) => {
            if (a.isPinned !== b.isPinned) return b.isPinned ? 1 : -1
            return new Date(b.createdAt) - new Date(a.createdAt)
          })
        } else if (sortOption === 'popular') {
          sortedTopics.sort((a, b) => {
            if (a.isPinned !== b.isPinned) return b.isPinned ? 1 : -1
            return b.views - a.views
          })
        } else if (sortOption === 'most_replies') {
          sortedTopics.sort((a, b) => {
            if (a.isPinned !== b.isPinned) return b.isPinned ? 1 : -1
            return b.replies - a.replies
          })
        }
        
        setTopics(sortedTopics)
        setTotalPages(Math.ceil(sortedTopics.length / 10))
      } catch (err) {
        console.error('Error fetching topics:', err)
        setError('Failed to load topics. Please try again later.')
      } finally {
        setLoading(false)
      }
    }
    
    if (forum) {
      fetchTopics()
    }
  }, [id, currentPage, sortOption, forum])
  
  const handleSortChange = (e) => {
    setSortOption(e.target.value)
  }
  
  const handlePageChange = (page) => {
    setCurrentPage(page)
  }
  
  // Format date for display
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now - date
    const diffSec = Math.floor(diffMs / 1000)
    const diffMin = Math.floor(diffSec / 60)
    const diffHour = Math.floor(diffMin / 60)
    const diffDay = Math.floor(diffHour / 24)
    
    if (diffDay > 0) {
      return `${diffDay} day${diffDay > 1 ? 's' : ''} ago`
    } else if (diffHour > 0) {
      return `${diffHour} hour${diffHour > 1 ? 's' : ''} ago`
    } else if (diffMin > 0) {
      return `${diffMin} minute${diffMin > 1 ? 's' : ''} ago`
    } else {
      return 'Just now'
    }
  }
  
  if (loading && !forum) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50 p-4">
        <div className="w-full max-w-6xl text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
          <p className="mt-2 text-gray-600">Loading forum details...</p>
        </div>
      </div>
    )
  }
  
  if (error && !forum) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50 p-4">
        <div className="w-full max-w-6xl text-center">
          <div className="mb-4 rounded-full bg-red-100 p-3 inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <p className="text-red-600">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="mt-4 rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
          >
            Try Again
          </button>
        </div>
      </div>
    )
  }
  
  if (!forum) return null
  
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto max-w-6xl">
        {/* Breadcrumb */}
        <div className="mb-6">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600">
                  <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                  </svg>
                  Home
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                  </svg>
                  <Link href="/forums" className="ml-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ml-2">
                    Forums
                  </Link>
                </div>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                  </svg>
                  <span className="ml-1 text-sm font-medium text-gray-500 md:ml-2">
                    {forum.name}
                  </span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
        
        {/* Forum Header */}
        <div className="mb-8">
          <div className="rounded-lg bg-white p-6 shadow-md">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{forum.name}</h1>
                <p className="mt-1 text-gray-600">{forum.description}</p>
                {!forum.isGeneral && (
                  <p className="mt-2 text-sm text-gray-500">
                    <Link href={`/schools/${forum.schoolId.id}`} className="text-blue-600 hover:underline">
                      {forum.schoolId.name}
                    </Link>
                    {' • '}
                    {forum.schoolId.location.city}, {forum.schoolId.location.state}
                  </p>
                )}
              </div>
              <div className="mt-4 md:mt-0">
                <Link 
                  href={`/forums/${forum.id}/new-topic`}
                  className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                >
                  Create New Topic
                </Link>
              </div>
            </div>
            
            <div className="mt-6 border-t pt-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center space-x-8">
                  <div className="text-center">
                    <p className="text-lg font-semibold text-gray-900">{forum.topics}</p>
                    <p className="text-xs text-gray-500">Topics</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-semibold text-gray-900">{forum.posts}</p>
                    <p className="text-xs text-gray-500">Posts</p>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-700">Moderators:</p>
                  <div className="mt-1 flex -space-x-2">
                    {forum.moderators.map(mod => (
                      <Link key={mod.id} href={`/profile/${mod.id}`} className="relative">
                        <img 
                          src={mod.profilePicture || 'https://via.placeholder.com/32'} 
                          alt={`${mod.firstName} ${mod.lastName}`}
                          className="h-8 w-8 rounded-full border-2 border-white"
                          title={`${mod.firstName} ${mod.lastName}`}
                        />
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Topics List */}
        <div className="mb-8">
          <div className="mb-4 flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
            <h2 className="text-xl font-semibold text-gray-900">Topics</h2>
            
            <div className="flex items-center space-x-2">
              <label htmlFor="sort" className="text-sm font-medium text-gray-700">
                Sort by:
              </label>
              <select
                id="sort"
                value={sortOption}
                onChange={handleSortChange}
                className="rounded-md border border-gray-300 px-3 py-1 text-sm focus:border-blue-500 focus:outline-none focus:ring-blue-500"
              >
                <option value="latest">Latest Activity</option>
                <option value="newest">Newest</option>
                <option value="popular">Most Viewed</option>
                <option value="most_replies">Most Replies</option>
              </select>
            </div>
          </div>
          
          {loading && topics.length === 0 ? (
            <div className="rounded-lg bg-white p-8 text-center shadow-md">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
              <p className="mt-2 text-gray-600">Loading topics...</p>
            </div>
          ) : topics.length === 0 ? (
            <div className="rounded-lg bg-white p-8 text-center shadow-md">
              <div className="mb-4 rounded-full bg-gray-100 p-3 inline-block">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <p className="text-gray-600">No topics have been created yet.</p>
              <Link 
                href={`/forums/${forum.id}/new-topic`}
                className="mt-4 inline-block rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
              >
                Create the First Topic
              </Link>
            </div>
          ) : (
            <div className="overflow-hidden rounded-lg bg-white shadow">
              <ul className="divide-y divide-gray-200">
                {topics.map(topic => (
                  <li key={topic.id} className={`${topic.isPinned ? 'bg-blue-50' : 'hover:bg-gray-50'}`}>
                    <Link href={`/forums/${forum.id}/topics/${topic.id}`} className="block">
                      <div className="px-6 py-4">
                        <div className="flex items-start">
                          <div className="mr-4 flex-shrink-0">
                            <img 
                              src={topic.userId.profilePicture || 'https://via.placeholder.com/40'} 
                              alt={`${topic.userId.firstName} ${topic.userId.lastName}`}
                              className="h-10 w-10 rounded-full"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center">
                              {topic.isPinned && (
                                <span className="mr-2 rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800">
                                  Pinned
                                </span>
                              )}
                              {topic.isLocked && (
                                <span className="mr-2 rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800">
                                  Locked
                                </span>
                              )}
                              <h3 className="text-lg font-medium text-gray-900 truncate">{topic.title}</h3>
                            </div>
                            <p className="mt-1 text-sm text-gray-500">
                              Started by {topic.userId.firstName} {topic.userId.lastName} • {formatDate(topic.createdAt)}
                            </p>
                          </div>
                          <div className="ml-4 flex-shrink-0 text-right">
                            <div className="flex items-center space-x-4">
                              <div className="text-center">
                                <p className="text-sm font-medium text-gray-900">{topic.views}</p>
                                <p className="text-xs text-gray-500">Views</p>
                              </div>
                              <div className="text-center">
                                <p className="text-sm font-medium text-gray-900">{topic.replies}</p>
                                <p className="text-xs text-gray-500">Replies</p>
                              </div>
                            </div>
                            <p className="mt-1 text-xs text-gray-500">
                              Last reply by {topic.lastPostUserId.firstName} {topic.lastPostUserId.lastName} • {formatDate(topic.lastPostAt)}
                            </p>
                          </div>
                        </div>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-6 flex justify-center">
              <nav className="inline-flex rounded-md shadow-sm">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  className="rounded-l-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                >
                  Previous
                </button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    className={`border border-gray-300 px-3 py-2 text-sm font-medium ${
                      currentPage === page
                        ? 'bg-blue-600 text-white'
                        : 'bg-white text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    {page}
                  </button>
                ))}
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className="rounded-r-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                >
                  Next
                </button>
              </nav>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
