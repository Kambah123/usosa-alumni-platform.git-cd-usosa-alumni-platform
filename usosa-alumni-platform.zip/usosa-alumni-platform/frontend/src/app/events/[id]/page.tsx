'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

export default function EventDetail({ params }) {
  const { id } = params
  const [event, setEvent] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [registrationStatus, setRegistrationStatus] = useState(null)
  const [isRegistering, setIsRegistering] = useState(false)
  
  // Mock data for event (would be fetched from API)
  const mockEvent = {
    id: '1',
    title: 'USOSA Annual General Meeting 2025',
    description: 'Annual gathering of all Unity Schools alumni to discuss progress and plans for the association. This event brings together alumni from all Federal Unity Schools across Nigeria to network, share ideas, and plan for the future of the association. The meeting will include presentations on the association\'s achievements, financial reports, and plans for the coming year. There will also be opportunities for alumni to connect with old classmates and make new connections.',
    eventType: 'Conference',
    startDate: '2025-07-15T09:00:00.000Z',
    endDate: '2025-07-15T17:00:00.000Z',
    location: {
      venue: 'Transcorp Hilton',
      address: '1 Aguiyi Ironsi Street',
      city: 'Abuja',
      state: 'FCT',
      country: 'Nigeria',
      isVirtual: false
    },
    organizer: {
      id: '101',
      firstName: 'Ahmed',
      lastName: 'Ibrahim',
      email: 'ahmed.ibrahim@example.com',
      profilePicture: null
    },
    isSchoolSpecific: false,
    registrationRequired: true,
    registrationDeadline: '2025-07-10T23:59:59.000Z',
    registrationFee: {
      amount: 5000,
      currency: 'NGN'
    },
    attendees: [
      {
        userId: {
          id: '201',
          firstName: 'Oluwaseun',
          lastName: 'Adeyemi',
          email: 'oluwaseun.adeyemi@example.com',
          profilePicture: null
        },
        registeredAt: '2025-03-15T14:30:00.000Z',
        status: 'registered',
        paymentStatus: 'completed'
      },
      {
        userId: {
          id: '202',
          firstName: 'Chioma',
          lastName: 'Okonkwo',
          email: 'chioma.okonkwo@example.com',
          profilePicture: null
        },
        registeredAt: '2025-03-16T09:45:00.000Z',
        status: 'registered',
        paymentStatus: 'completed'
      },
      {
        userId: {
          id: '203',
          firstName: 'Ibrahim',
          lastName: 'Musa',
          email: 'ibrahim.musa@example.com',
          profilePicture: null
        },
        registeredAt: '2025-03-16T11:20:00.000Z',
        status: 'registered',
        paymentStatus: 'pending'
      }
    ],
    attendeeCount: 156,
    capacity: 300,
    agenda: [
      {
        time: '09:00 - 09:30',
        title: 'Registration and Welcome',
        description: 'Check-in and welcome refreshments',
        speaker: null
      },
      {
        time: '09:30 - 10:00',
        title: 'Opening Address',
        description: 'Welcome address by the USOSA President',
        speaker: 'Dr. Michael Olawale'
      },
      {
        time: '10:00 - 11:00',
        title: 'Annual Report Presentation',
        description: 'Presentation of the association\'s activities and achievements',
        speaker: 'Mrs. Fatima Abdullahi'
      },
      {
        time: '11:00 - 12:00',
        title: 'Financial Report',
        description: 'Presentation of the association\'s financial status',
        speaker: 'Mr. John Okafor'
      },
      {
        time: '12:00 - 13:00',
        title: 'Lunch Break',
        description: 'Networking lunch',
        speaker: null
      },
      {
        time: '13:00 - 14:30',
        title: 'Strategic Planning Session',
        description: 'Discussion on future plans and initiatives',
        speaker: 'Panel Discussion'
      },
      {
        time: '14:30 - 15:30',
        title: 'Open Forum',
        description: 'Q&A session with the executive committee',
        speaker: null
      },
      {
        time: '15:30 - 16:30',
        title: 'Elections',
        description: 'Election of new executive committee members',
        speaker: 'Electoral Committee'
      },
      {
        time: '16:30 - 17:00',
        title: 'Closing Remarks',
        description: 'Vote of thanks and closing address',
        speaker: 'Incoming USOSA President'
      }
    ],
    sponsors: [
      {
        name: 'Unity Bank',
        logo: null,
        website: 'https://www.unitybank.ng'
      },
      {
        name: 'Federal Ministry of Education',
        logo: null,
        website: 'https://education.gov.ng'
      },
      {
        name: 'Nigerian Breweries',
        logo: null,
        website: 'https://www.nbplc.com'
      }
    ],
    status: 'published',
    visibility: 'alumni_only',
    createdAt: '2025-03-01T10:30:00.000Z',
    createdBy: {
      firstName: 'Ahmed',
      lastName: 'Ibrahim'
    },
    updatedAt: '2025-03-05T14:15:00.000Z',
    updatedBy: {
      firstName: 'Ahmed',
      lastName: 'Ibrahim'
    }
  }
  
  useEffect(() => {
    // Simulate API call to fetch event details
    const fetchEvent = async () => {
      try {
        setLoading(true)
        
        // This would be replaced with actual API call
        // const response = await fetch(`/api/events/${id}`)
        // const data = await response.json()
        // setEvent(data.event)
        
        // Using mock data for now
        await new Promise(resolve => setTimeout(resolve, 1000))
        setEvent(mockEvent)
        
        // Check if user is registered for this event
        // This would be replaced with actual API call to check registration status
        // const regResponse = await fetch(`/api/events/${id}/registration-status`)
        // const regData = await regResponse.json()
        // setRegistrationStatus(regData.status)
        
        // Mock registration status
        setRegistrationStatus('not_registered') // or 'registered', 'cancelled'
      } catch (err) {
        console.error('Error fetching event details:', err)
        setError('Failed to load event details. Please try again later.')
      } finally {
        setLoading(false)
      }
    }
    
    if (id) {
      fetchEvent()
    }
  }, [id])
  
  const handleRegister = async () => {
    try {
      setIsRegistering(true)
      
      // This would be replaced with actual API call
      // const response = await fetch(`/api/events/${id}/register`, {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json'
      //   }
      // })
      
      // if (!response.ok) {
      //   const errorData = await response.json()
      //   throw new Error(errorData.message || 'Failed to register for event')
      // }
      
      // const data = await response.json()
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      // Update registration status
      setRegistrationStatus('registered')
      
      // Show success message
      alert('You have successfully registered for this event!')
    } catch (err) {
      console.error('Error registering for event:', err)
      alert(`Registration failed: ${err.message}`)
    } finally {
      setIsRegistering(false)
    }
  }
  
  const handleCancelRegistration = async () => {
    if (!confirm('Are you sure you want to cancel your registration?')) {
      return
    }
    
    try {
      setIsRegistering(true)
      
      // This would be replaced with actual API call
      // const response = await fetch(`/api/events/${id}/cancel-registration`, {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json'
      //   }
      // })
      
      // if (!response.ok) {
      //   const errorData = await response.json()
      //   throw new Error(errorData.message || 'Failed to cancel registration')
      // }
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      // Update registration status
      setRegistrationStatus('not_registered')
      
      // Show success message
      alert('Your registration has been cancelled.')
    } catch (err) {
      console.error('Error cancelling registration:', err)
      alert(`Cancellation failed: ${err.message}`)
    } finally {
      setIsRegistering(false)
    }
  }
  
  // Format date for display
  const formatDate = (dateString) => {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }
  
  // Format time for display
  const formatTime = (dateString) => {
    const options = { hour: '2-digit', minute: '2-digit' }
    return new Date(dateString).toLocaleTimeString(undefined, options)
  }
  
  // Calculate days remaining until event
  const getDaysRemaining = (dateString) => {
    const eventDate = new Date(dateString)
    const today = new Date()
    const diffTime = eventDate - today
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }
  
  // Calculate days remaining until registration deadline
  const getRegistrationDaysRemaining = (dateString) => {
    if (!dateString) return null
    const deadlineDate = new Date(dateString)
    const today = new Date()
    const diffTime = deadlineDate - today
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }
  
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto max-w-7xl">
        <div className="mb-6">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600">
                  <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                  </svg>
                  Home
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                  </svg>
                  <Link href="/events" className="ml-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ml-2">
                    Events
                  </Link>
                </div>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                  </svg>
                  <span className="ml-1 text-sm font-medium text-gray-500 md:ml-2 line-clamp-1">
                    {loading ? 'Loading...' : event?.title}
                  </span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
        
        {loading ? (
          <div className="flex min-h-[400px] items-center justify-center">
            <div className="text-center">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
              <p className="mt-2 text-gray-600">Loading event details...</p>
            </div>
          </div>
        ) : error ? (
          <div className="rounded-lg bg-white p-8 text-center shadow-md">
            <div className="mb-4 rounded-full bg-red-100 p-3 inline-block">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="text-red-600">{error}</p>
            <button 
              onClick={() => window.location.reload()}
              className="mt-4 rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              Try Again
            </button>
          </div>
        ) : event ? (
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <div className="rounded-lg bg-white shadow-md overflow-hidden">
                <div className="h-64 overflow-hidden bg-gray-200">
                  {event.banner ? (
                    <img 
                      src={event.banner} 
                      alt={event.title} 
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-gradient-to-r from-blue-500 to-indigo-600">
                      <div className="text-center text-white">
                        <div className="mb-2">
                          <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                        </div>
                        <p className="text-2xl font-semibold">{event.eventType}</p>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="p-6">
                  <div className="mb-4 flex flex-wrap gap-2">
                    <span className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${
                      event.isSchoolSpecific
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {event.isSchoolSpecific ? 'School Event' : 'USOSA Event'}
                    </span>
                    
                    <span className="inline-flex rounded-full bg-indigo-100 px-3 py-1 text-xs font-semibold text-indigo-800">
                      {event.eventType}
                    </span>
                    
                    {event.location.isVirtual && (
                      <span className="inline-flex rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-800">
                        Virtual
                      </span>
                    )}
                    
                    {getDaysRemaining(event.startDate) <= 7 && getDaysRemaining(event.startDate) > 0 && (
                      <span className="inline-flex rounded-full bg-yellow-100 px-3 py-1 text-xs font-semibold text-yellow-800">
                        Coming Soon
                      </span>
                    )}
                    
                    {getDaysRemaining(event.startDate) <= 0 && getDaysRemaining(event.endDate) >= 0 && (
                      <span className="inline-flex rounded-full bg-red-100 px-3 py-1 text-xs font-semibold text-red-800">
                        Happening Now
                      </span>
                    )}
                  </div>
                  
                  <h1 className="mb-4 text-3xl font-bold text-gray-900">{event.title}</h1>
                  
                  <div className="mb-6 space-y-4">
                    <div className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                      <div>
                        <p className="font-medium text-gray-900">Date & Time</p>
                        <p className="text-gray-700">{formatDate(event.startDate)}</p>
                        <p className="text-gray-700">{formatTime(event.startDate)} - {formatTime(event.endDate)}</p>
                        <p className="mt-1 text-sm text-blue-600">
                          {getDaysRemaining(event.startDate) > 0 
                            ? `${getDaysRemaining(event.startDate)} days remaining` 
                            : getDaysRemaining(event.endDate) >= 0 
                              ? 'Event in progress' 
                              : 'Event has ended'}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                      <div>
                        <p className="font-medium text-gray-900">Location</p>
                        {event.location.isVirtual ? (
                          <>
                            <p className="text-gray-700">Virtual Event</p>
                            {event.location.virtualLink && (
                              <a 
                                href={event.location.virtualLink} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:underline"
                              >
                                Join Event
                              </a>
                            )}
                          </>
                        ) : (
                          <>
                            <p className="text-gray-700">{event.location.venue}</p>
                            <p className="text-gray-700">{event.location.address}</p>
                            <p className="text-gray-700">{event.location.city}, {event.location.state}</p>
                            <a 
                              href={`https://maps.google.com/?q=${encodeURIComponent(
                                `${event.location.venue}, ${event.location.address}, ${event.location.city}, ${event.location.state}, ${event.location.country}`
                              )}`}
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline"
                            >
                              View on Map
                            </a>
                          </>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                      <div>
                        <p className="font-medium text-gray-900">Organizer</p>
                        <p className="text-gray-700">{event.organizer.firstName} {event.organizer.lastName}</p>
                        <a 
                          href={`mailto:${event.organizer.email}`}
                          className="text-blue-600 hover:underline"
                        >
                          {event.organizer.email}
                        </a>
                      </div>
                    </div>
                    
                    {event.registrationRequired && (
                      <div className="flex items-start">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                        </svg>
                        <div>
                          <p className="font-medium text-gray-900">Registration</p>
                          {event.registrationDeadline && (
                            <p className="text-gray-700">
                              Deadline: {formatDate(event.registrationDeadline)} ({formatTime(event.registrationDeadline)})
                            </p>
                          )}
                          {event.registrationFee && event.registrationFee.amount > 0 && (
                            <p className="text-gray-700">
                              Fee: {event.registrationFee.currency} {event.registrationFee.amount.toLocaleString()}
                            </p>
                          )}
                          {event.registrationDeadline && getRegistrationDaysRemaining(event.registrationDeadline) > 0 && (
                            <p className="mt-1 text-sm text-blue-600">
                              {getRegistrationDaysRemaining(event.registrationDeadline)} days remaining to register
                            </p>
                          )}
                          {event.registrationDeadline && getRegistrationDaysRemaining(event.registrationDeadline) <= 0 && (
                            <p className="mt-1 text-sm text-red-600">
                              Registration deadline has passed
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                      <div>
                        <p className="font-medium text-gray-900">Attendees</p>
                        <p className="text-gray-700">
                          {event.attendeeCount} {event.capacity ? `/ ${event.capacity}` : ''} registered
                        </p>
                        {event.capacity && (
                          <div className="mt-1 h-2 w-full max-w-xs rounded-full bg-gray-200">
                            <div 
                              className="h-2 rounded-full bg-blue-600" 
                              style={{ width: `${Math.min(100, (event.attendeeCount / event.capacity) * 100)}%` }}
                            ></div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-200 pt-6">
                    <h2 className="mb-4 text-xl font-bold text-gray-900">About This Event</h2>
                    <div className="prose max-w-none text-gray-700">
                      <p>{event.description}</p>
                    </div>
                  </div>
                  
                  {event.agenda && event.agenda.length > 0 && (
                    <div className="mt-8 border-t border-gray-200 pt-6">
                      <h2 className="mb-4 text-xl font-bold text-gray-900">Event Agenda</h2>
                      <div className="space-y-4">
                        {event.agenda.map((item, index) => (
                          <div key={index} className="rounded-lg border border-gray-200 p-4">
                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                              <h3 className="font-medium text-gray-900">{item.title}</h3>
                              <span className="mt-1 text-sm text-gray-500 sm:mt-0">{item.time}</span>
                            </div>
                            {item.description && (
                              <p className="mt-2 text-gray-700">{item.description}</p>
                            )}
                            {item.speaker && (
                              <p className="mt-1 text-sm text-gray-600">Speaker: {item.speaker}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {event.sponsors && event.sponsors.length > 0 && (
                    <div className="mt-8 border-t border-gray-200 pt-6">
                      <h2 className="mb-4 text-xl font-bold text-gray-900">Sponsors</h2>
                      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                        {event.sponsors.map((sponsor, index) => (
                          <a 
                            key={index}
                            href={sponsor.website}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex flex-col items-center justify-center rounded-lg border border-gray-200 p-4 text-center hover:bg-gray-50"
                          >
                            {sponsor.logo ? (
                              <img 
                                src={sponsor.logo} 
                                alt={sponsor.name} 
                                className="mb-2 h-12 w-auto object-contain"
                              />
                            ) : (
                              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-600">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                              </div>
                            )}
                            <span className="text-sm font-medium text-gray-900">{sponsor.name}</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div>
              <div className="sticky top-6 space-y-6">
                <div className="rounded-lg bg-white p-6 shadow-md">
                  <h2 className="mb-4 text-xl font-bold text-gray-900">Registration</h2>
                  
                  {event.registrationRequired ? (
                    <>
                      {event.registrationDeadline && getRegistrationDaysRemaining(event.registrationDeadline) <= 0 ? (
                        <div className="rounded-md bg-yellow-50 p-4">
                          <div className="flex">
                            <div className="flex-shrink-0">
                              <svg className="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                              </svg>
                            </div>
                            <div className="ml-3">
                              <h3 className="text-sm font-medium text-yellow-800">Registration closed</h3>
                              <div className="mt-2 text-sm text-yellow-700">
                                <p>The registration deadline for this event has passed.</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : event.capacity && event.attendeeCount >= event.capacity ? (
                        <div className="rounded-md bg-yellow-50 p-4">
                          <div className="flex">
                            <div className="flex-shrink-0">
                              <svg className="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                              </svg>
                            </div>
                            <div className="ml-3">
                              <h3 className="text-sm font-medium text-yellow-800">Event full</h3>
                              <div className="mt-2 text-sm text-yellow-700">
                                <p>This event has reached maximum capacity.</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : registrationStatus === 'registered' ? (
                        <div className="rounded-md bg-green-50 p-4">
                          <div className="flex">
                            <div className="flex-shrink-0">
                              <svg className="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                              </svg>
                            </div>
                            <div className="ml-3">
                              <h3 className="text-sm font-medium text-green-800">You're registered</h3>
                              <div className="mt-2 text-sm text-green-700">
                                <p>You have successfully registered for this event.</p>
                              </div>
                              <div className="mt-4">
                                <button
                                  type="button"
                                  onClick={handleCancelRegistration}
                                  disabled={isRegistering}
                                  className={`rounded-md bg-green-50 px-4 py-2 text-sm font-medium text-green-800 hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-green-600 focus:ring-offset-2 focus:ring-offset-green-50 ${
                                    isRegistering ? 'cursor-not-allowed opacity-75' : ''
                                  }`}
                                >
                                  {isRegistering ? 'Cancelling...' : 'Cancel Registration'}
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div>
                          {event.registrationFee && event.registrationFee.amount > 0 && (
                            <div className="mb-4">
                              <p className="text-lg font-medium text-gray-900">
                                {event.registrationFee.currency} {event.registrationFee.amount.toLocaleString()}
                              </p>
                              <p className="text-sm text-gray-600">Registration fee</p>
                            </div>
                          )}
                          
                          <button
                            type="button"
                            onClick={handleRegister}
                            disabled={isRegistering}
                            className={`w-full rounded-md bg-blue-600 px-4 py-3 text-center font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                              isRegistering ? 'cursor-not-allowed opacity-75' : ''
                            }`}
                          >
                            {isRegistering ? (
                              <span className="flex items-center justify-center">
                                <svg className="mr-2 h-4 w-4 animate-spin text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Registering...
                              </span>
                            ) : (
                              'Register for Event'
                            )}
                          </button>
                          
                          {event.registrationDeadline && (
                            <p className="mt-2 text-center text-sm text-gray-600">
                              Registration closes on {formatDate(event.registrationDeadline)}
                            </p>
                          )}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="rounded-md bg-blue-50 p-4">
                      <div className="flex">
                        <div className="flex-shrink-0">
                          <svg className="h-5 w-5 text-blue-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z" clipRule="evenodd" />
                          </svg>
                        </div>
                        <div className="ml-3">
                          <h3 className="text-sm font-medium text-blue-800">No registration required</h3>
                          <div className="mt-2 text-sm text-blue-700">
                            <p>You can attend this event without registering.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="rounded-lg bg-white p-6 shadow-md">
                  <h2 className="mb-4 text-xl font-bold text-gray-900">Share Event</h2>
                  <div className="flex space-x-4">
                    <button
                      onClick={() => {
                        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, '_blank');
                      }}
                      className="flex items-center justify-center rounded-full bg-blue-600 p-2 text-white hover:bg-blue-700"
                      aria-label="Share on Facebook"
                    >
                      <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" />
                      </svg>
                    </button>
                    <button
                      onClick={() => {
                        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(event.title)}&url=${encodeURIComponent(window.location.href)}`, '_blank');
                      }}
                      className="flex items-center justify-center rounded-full bg-blue-400 p-2 text-white hover:bg-blue-500"
                      aria-label="Share on Twitter"
                    >
                      <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                      </svg>
                    </button>
                    <button
                      onClick={() => {
                        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`, '_blank');
                      }}
                      className="flex items-center justify-center rounded-full bg-blue-700 p-2 text-white hover:bg-blue-800"
                      aria-label="Share on LinkedIn"
                    >
                      <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                      </svg>
                    </button>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(window.location.href);
                        alert('Link copied to clipboard!');
                      }}
                      className="flex items-center justify-center rounded-full bg-gray-600 p-2 text-white hover:bg-gray-700"
                      aria-label="Copy link"
                    >
                      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="rounded-lg bg-white p-6 shadow-md">
                  <h2 className="mb-4 text-xl font-bold text-gray-900">Contact Organizer</h2>
                  <p className="mb-4 text-gray-700">
                    Have questions about this event? Contact the organizer directly.
                  </p>
                  <a
                    href={`mailto:${event.organizer.email}?subject=Question about ${encodeURIComponent(event.title)}`}
                    className="inline-flex items-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                  >
                    <svg className="mr-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    Email Organizer
                  </a>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="rounded-lg bg-white p-8 text-center shadow-md">
            <div className="mb-4 rounded-full bg-red-100 p-3 inline-block">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="text-red-600">Event not found</p>
            <Link 
              href="/events"
              className="mt-4 inline-block rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              Back to Events
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
