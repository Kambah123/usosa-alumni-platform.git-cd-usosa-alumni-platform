'use client'

import { useState } from 'react'
import Link from 'next/link'

export default function CreateEvent() {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    eventType: 'Conference',
    startDate: '',
    startTime: '',
    endDate: '',
    endTime: '',
    isVirtual: false,
    venue: '',
    address: '',
    city: '',
    state: '',
    virtualLink: '',
    isSchoolSpecific: false,
    schoolId: '',
    registrationRequired: true,
    registrationDeadline: '',
    registrationDeadlineTime: '',
    registrationFeeAmount: '',
    registrationFeeCurrency: 'NGN',
    capacity: '',
    visibility: 'alumni_only'
  })
  
  const [agendaItems, setAgendaItems] = useState([
    { time: '', title: '', description: '', speaker: '' }
  ])
  
  const [sponsors, setSponsors] = useState([
    { name: '', website: '' }
  ])
  
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)
  
  // Mock data for schools (would be fetched from API)
  const mockSchools = [
    {
      id: '1',
      name: 'Federal Government College, Buni-Yadi',
      shortName: 'FGC Buni-Yadi'
    },
    {
      id: '2',
      name: 'Federal Government Girls College, Potiskum',
      shortName: 'FGGC Potiskum'
    },
    {
      id: '3',
      name: 'Federal Government College, Jos',
      shortName: 'FGC Jos'
    },
    {
      id: '4',
      name: 'King\'s College, Lagos',
      shortName: 'KC Lagos'
    },
    {
      id: '5',
      name: 'Queen\'s College, Lagos',
      shortName: 'QC Lagos'
    }
  ]
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
  }
  
  const handleAgendaChange = (index, field, value) => {
    const newAgendaItems = [...agendaItems]
    newAgendaItems[index][field] = value
    setAgendaItems(newAgendaItems)
  }
  
  const addAgendaItem = () => {
    setAgendaItems([...agendaItems, { time: '', title: '', description: '', speaker: '' }])
  }
  
  const removeAgendaItem = (index) => {
    if (agendaItems.length > 1) {
      const newAgendaItems = [...agendaItems]
      newAgendaItems.splice(index, 1)
      setAgendaItems(newAgendaItems)
    }
  }
  
  const handleSponsorChange = (index, field, value) => {
    const newSponsors = [...sponsors]
    newSponsors[index][field] = value
    setSponsors(newSponsors)
  }
  
  const addSponsor = () => {
    setSponsors([...sponsors, { name: '', website: '' }])
  }
  
  const removeSponsor = (index) => {
    if (sponsors.length > 1) {
      const newSponsors = [...sponsors]
      newSponsors.splice(index, 1)
      setSponsors(newSponsors)
    }
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    try {
      setLoading(true)
      setError(null)
      
      // Validate form
      if (!formData.title || !formData.description || !formData.startDate || !formData.startTime || !formData.endDate || !formData.endTime) {
        throw new Error('Please fill in all required fields')
      }
      
      // Validate location
      if (!formData.isVirtual && (!formData.venue || !formData.city || !formData.state)) {
        throw new Error('Please provide venue details')
      }
      
      if (formData.isVirtual && !formData.virtualLink) {
        throw new Error('Please provide a virtual meeting link')
      }
      
      // Validate school selection
      if (formData.isSchoolSpecific && !formData.schoolId) {
        throw new Error('Please select a school')
      }
      
      // Validate registration deadline
      if (formData.registrationRequired && (!formData.registrationDeadline || !formData.registrationDeadlineTime)) {
        throw new Error('Please provide a registration deadline')
      }
      
      // Validate agenda items
      const invalidAgendaItems = agendaItems.filter(item => !item.time || !item.title)
      if (invalidAgendaItems.length > 0) {
        throw new Error('Please provide time and title for all agenda items')
      }
      
      // Validate sponsors
      const invalidSponsors = sponsors.filter(sponsor => !sponsor.name)
      if (invalidSponsors.length > 0) {
        throw new Error('Please provide names for all sponsors')
      }
      
      // Prepare data for API
      const startDateTime = new Date(`${formData.startDate}T${formData.startTime}`)
      const endDateTime = new Date(`${formData.endDate}T${formData.endTime}`)
      
      let registrationDeadlineDateTime = null
      if (formData.registrationRequired && formData.registrationDeadline && formData.registrationDeadlineTime) {
        registrationDeadlineDateTime = new Date(`${formData.registrationDeadline}T${formData.registrationDeadlineTime}`)
      }
      
      const eventData = {
        title: formData.title,
        description: formData.description,
        eventType: formData.eventType,
        startDate: startDateTime.toISOString(),
        endDate: endDateTime.toISOString(),
        location: {
          isVirtual: formData.isVirtual,
          venue: formData.isVirtual ? 'Virtual Event' : formData.venue,
          address: formData.isVirtual ? 'Online' : formData.address,
          city: formData.isVirtual ? 'N/A' : formData.city,
          state: formData.isVirtual ? 'N/A' : formData.state,
          country: 'Nigeria',
          virtualLink: formData.isVirtual ? formData.virtualLink : null
        },
        isSchoolSpecific: formData.isSchoolSpecific,
        schoolId: formData.isSchoolSpecific ? formData.schoolId : null,
        registrationRequired: formData.registrationRequired,
        registrationDeadline: registrationDeadlineDateTime ? registrationDeadlineDateTime.toISOString() : null,
        registrationFee: {
          amount: formData.registrationFeeAmount ? parseFloat(formData.registrationFeeAmount) : 0,
          currency: formData.registrationFeeCurrency
        },
        capacity: formData.capacity ? parseInt(formData.capacity) : null,
        agenda: agendaItems.map(item => ({
          time: item.time,
          title: item.title,
          description: item.description || null,
          speaker: item.speaker || null
        })),
        sponsors: sponsors.map(sponsor => ({
          name: sponsor.name,
          website: sponsor.website || null
        })),
        visibility: formData.visibility,
        status: 'draft'
      }
      
      // This would be replaced with actual API call
      // const response = await fetch('/api/events', {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json'
      //   },
      //   body: JSON.stringify(eventData)
      // })
      
      // if (!response.ok) {
      //   const errorData = await response.json()
      //   throw new Error(errorData.message || 'Failed to create event')
      // }
      
      // const data = await response.json()
      
      // Simulate API call
      console.log('Event data to be sent:', eventData)
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      setSuccess(true)
      
      // Reset form after successful submission
      setFormData({
        title: '',
        description: '',
        eventType: 'Conference',
        startDate: '',
        startTime: '',
        endDate: '',
        endTime: '',
        isVirtual: false,
        venue: '',
        address: '',
        city: '',
        state: '',
        virtualLink: '',
        isSchoolSpecific: false,
        schoolId: '',
        registrationRequired: true,
        registrationDeadline: '',
        registrationDeadlineTime: '',
        registrationFeeAmount: '',
        registrationFeeCurrency: 'NGN',
        capacity: '',
        visibility: 'alumni_only'
      })
      setAgendaItems([{ time: '', title: '', description: '', speaker: '' }])
      setSponsors([{ name: '', website: '' }])
    } catch (err) {
      console.error('Error creating event:', err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto max-w-7xl">
        <div className="mb-6">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link href="/" className="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600">
                  <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                  </svg>
                  Home
                </Link>
              </li>
              <li>
                <div className="flex items-center">
                  <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                  </svg>
                  <Link href="/events" className="ml-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ml-2">
                    Events
                  </Link>
                </div>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                  </svg>
                  <span className="ml-1 text-sm font-medium text-gray-500 md:ml-2">
                    Create Event
                  </span>
                </div>
              </li>
            </ol>
          </nav>
        </div>
        
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-900">Create New Event</h1>
          <p className="mt-2 text-gray-600">Create a new event for USOSA alumni to connect and collaborate</p>
        </div>
        
        {success ? (
          <div className="rounded-lg bg-white p-8 shadow-md">
            <div className="text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                <svg className="h-6 w-6 text-green-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 className="mt-4 text-2xl font-medium text-gray-900">Event Created Successfully!</h2>
              <p className="mt-2 text-gray-600">
                Your event has been created and is now in draft mode. You can publish it when you're ready.
              </p>
              <div className="mt-6">
                <Link
                  href="/events"
                  className="inline-flex items-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                >
                  View All Events
                </Link>
                <button
                  type="button"
                  onClick={() => setSuccess(false)}
                  className="ml-4 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Create Another Event
                </button>
              </div>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-8">
            {error && (
              <div className="rounded-md bg-red-50 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">Error</h3>
                    <div className="mt-2 text-sm text-red-700">
                      <p>{error}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div className="rounded-lg bg-white p-6 shadow-md">
              <h2 className="mb-4 text-xl font-bold text-gray-900">Event Details</h2>
              
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div className="md:col-span-2">
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                    Event Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="title"
                    id="title"
                    value={formData.title}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="e.g. USOSA Annual General Meeting 2025"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                    Event Description <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    name="description"
                    id="description"
                    rows={4}
                    value={formData.description}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="Provide a detailed description of the event..."
                  />
                </div>
                
                <div>
                  <label htmlFor="eventType" className="block text-sm font-medium text-gray-700">
                    Event Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="eventType"
                    id="eventType"
                    value={formData.eventType}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="Reunion">Reunion</option>
                    <option value="Seminar">Seminar</option>
                    <option value="Workshop">Workshop</option>
                    <option value="Conference">Conference</option>
                    <option value="Networking">Networking</option>
                    <option value="Social">Social</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="visibility" className="block text-sm font-medium text-gray-700">
                    Visibility <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="visibility"
                    id="visibility"
                    value={formData.visibility}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="public">Public (Anyone can view)</option>
                    <option value="alumni_only">Alumni Only (All USOSA alumni)</option>
                    <option value="school_alumni_only">School Alumni Only (Specific school alumni)</option>
                    <option value="invite_only">Invite Only (Only invited users)</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">
                    Start Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    name="startDate"
                    id="startDate"
                    value={formData.startDate}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label htmlFor="startTime" className="block text-sm font-medium text-gray-700">
                    Start Time <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="time"
                    name="startTime"
                    id="startTime"
                    value={formData.startTime}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label htmlFor="endDate" className="block text-sm font-medium text-gray-700">
                    End Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    name="endDate"
                    id="endDate"
                    value={formData.endDate}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label htmlFor="endTime" className="block text-sm font-medium text-gray-700">
                    End Time <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="time"
                    name="endTime"
                    id="endTime"
                    value={formData.endTime}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-md">
              <h2 className="mb-4 text-xl font-bold text-gray-900">Location</h2>
              
              <div className="mb-4">
                <div className="flex items-center">
                  <input
                    id="isVirtual"
                    name="isVirtual"
                    type="checkbox"
                    checked={formData.isVirtual}
                    onChange={handleChange}
                    className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <label htmlFor="isVirtual" className="ml-2 block text-sm text-gray-700">
                    This is a virtual event
                  </label>
                </div>
              </div>
              
              {formData.isVirtual ? (
                <div>
                  <label htmlFor="virtualLink" className="block text-sm font-medium text-gray-700">
                    Virtual Meeting Link <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="url"
                    name="virtualLink"
                    id="virtualLink"
                    value={formData.virtualLink}
                    onChange={handleChange}
                    required={formData.isVirtual}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="e.g. https://zoom.us/j/example"
                  />
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                  <div>
                    <label htmlFor="venue" className="block text-sm font-medium text-gray-700">
                      Venue Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="venue"
                      id="venue"
                      value={formData.venue}
                      onChange={handleChange}
                      required={!formData.isVirtual}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder="e.g. Transcorp Hilton"
                    />
                  </div>
                  
                  <div className="md:col-span-2">
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700">
                      Address
                    </label>
                    <input
                      type="text"
                      name="address"
                      id="address"
                      value={formData.address}
                      onChange={handleChange}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder="e.g. 1 Aguiyi Ironsi Street"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="city" className="block text-sm font-medium text-gray-700">
                      City <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="city"
                      id="city"
                      value={formData.city}
                      onChange={handleChange}
                      required={!formData.isVirtual}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder="e.g. Abuja"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="state" className="block text-sm font-medium text-gray-700">
                      State <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="state"
                      id="state"
                      value={formData.state}
                      onChange={handleChange}
                      required={!formData.isVirtual}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder="e.g. FCT"
                    />
                  </div>
                </div>
              )}
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-md">
              <h2 className="mb-4 text-xl font-bold text-gray-900">School Association</h2>
              
              <div className="mb-4">
                <div className="flex items-center">
                  <input
                    id="isSchoolSpecific"
                    name="isSchoolSpecific"
                    type="checkbox"
                    checked={formData.isSchoolSpecific}
                    onChange={handleChange}
                    className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <label htmlFor="isSchoolSpecific" className="ml-2 block text-sm text-gray-700">
                    This event is specific to a Unity School
                  </label>
                </div>
              </div>
              
              {formData.isSchoolSpecific && (
                <div>
                  <label htmlFor="schoolId" className="block text-sm font-medium text-gray-700">
                    Select School <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="schoolId"
                    id="schoolId"
                    value={formData.schoolId}
                    onChange={handleChange}
                    required={formData.isSchoolSpecific}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="">Select a school</option>
                    {mockSchools.map(school => (
                      <option key={school.id} value={school.id}>
                        {school.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-md">
              <h2 className="mb-4 text-xl font-bold text-gray-900">Registration</h2>
              
              <div className="mb-4">
                <div className="flex items-center">
                  <input
                    id="registrationRequired"
                    name="registrationRequired"
                    type="checkbox"
                    checked={formData.registrationRequired}
                    onChange={handleChange}
                    className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <label htmlFor="registrationRequired" className="ml-2 block text-sm text-gray-700">
                    Registration is required for this event
                  </label>
                </div>
              </div>
              
              {formData.registrationRequired && (
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                  <div>
                    <label htmlFor="registrationDeadline" className="block text-sm font-medium text-gray-700">
                      Registration Deadline Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      name="registrationDeadline"
                      id="registrationDeadline"
                      value={formData.registrationDeadline}
                      onChange={handleChange}
                      required={formData.registrationRequired}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="registrationDeadlineTime" className="block text-sm font-medium text-gray-700">
                      Registration Deadline Time <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="time"
                      name="registrationDeadlineTime"
                      id="registrationDeadlineTime"
                      value={formData.registrationDeadlineTime}
                      onChange={handleChange}
                      required={formData.registrationRequired}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="capacity" className="block text-sm font-medium text-gray-700">
                      Maximum Capacity
                    </label>
                    <input
                      type="number"
                      name="capacity"
                      id="capacity"
                      value={formData.capacity}
                      onChange={handleChange}
                      min="1"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder="Leave blank for unlimited"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="registrationFeeAmount" className="block text-sm font-medium text-gray-700">
                      Registration Fee
                    </label>
                    <div className="mt-1 flex rounded-md shadow-sm">
                      <span className="inline-flex items-center rounded-l-md border border-r-0 border-gray-300 bg-gray-50 px-3 text-gray-500 sm:text-sm">
                        <select
                          name="registrationFeeCurrency"
                          id="registrationFeeCurrency"
                          value={formData.registrationFeeCurrency}
                          onChange={handleChange}
                          className="border-0 bg-transparent focus:ring-0"
                        >
                          <option value="NGN">NGN</option>
                          <option value="USD">USD</option>
                          <option value="EUR">EUR</option>
                          <option value="GBP">GBP</option>
                        </select>
                      </span>
                      <input
                        type="number"
                        name="registrationFeeAmount"
                        id="registrationFeeAmount"
                        value={formData.registrationFeeAmount}
                        onChange={handleChange}
                        min="0"
                        step="0.01"
                        className="block w-full flex-1 rounded-none rounded-r-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                        placeholder="0.00 (free)"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900">Event Agenda</h2>
                <button
                  type="button"
                  onClick={addAgendaItem}
                  className="inline-flex items-center rounded-md border border-transparent bg-blue-100 px-3 py-2 text-sm font-medium leading-4 text-blue-700 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                  <svg className="-ml-0.5 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                  Add Item
                </button>
              </div>
              
              <div className="space-y-4">
                {agendaItems.map((item, index) => (
                  <div key={index} className="rounded-lg border border-gray-200 p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-medium text-gray-900">Agenda Item {index + 1}</h3>
                      {agendaItems.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeAgendaItem(index)}
                          className="inline-flex items-center rounded-md border border-transparent bg-red-100 px-3 py-2 text-sm font-medium leading-4 text-red-700 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                        >
                          <svg className="-ml-0.5 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                          </svg>
                          Remove
                        </button>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <div>
                        <label htmlFor={`agenda-time-${index}`} className="block text-sm font-medium text-gray-700">
                          Time <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id={`agenda-time-${index}`}
                          value={item.time}
                          onChange={(e) => handleAgendaChange(index, 'time', e.target.value)}
                          required
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="e.g. 09:00 - 10:00"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor={`agenda-title-${index}`} className="block text-sm font-medium text-gray-700">
                          Title <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id={`agenda-title-${index}`}
                          value={item.title}
                          onChange={(e) => handleAgendaChange(index, 'title', e.target.value)}
                          required
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="e.g. Opening Address"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor={`agenda-description-${index}`} className="block text-sm font-medium text-gray-700">
                          Description
                        </label>
                        <input
                          type="text"
                          id={`agenda-description-${index}`}
                          value={item.description}
                          onChange={(e) => handleAgendaChange(index, 'description', e.target.value)}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="e.g. Welcome address by the USOSA President"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor={`agenda-speaker-${index}`} className="block text-sm font-medium text-gray-700">
                          Speaker
                        </label>
                        <input
                          type="text"
                          id={`agenda-speaker-${index}`}
                          value={item.speaker}
                          onChange={(e) => handleAgendaChange(index, 'speaker', e.target.value)}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="e.g. Dr. Michael Olawale"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900">Sponsors</h2>
                <button
                  type="button"
                  onClick={addSponsor}
                  className="inline-flex items-center rounded-md border border-transparent bg-blue-100 px-3 py-2 text-sm font-medium leading-4 text-blue-700 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                  <svg className="-ml-0.5 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                  Add Sponsor
                </button>
              </div>
              
              <div className="space-y-4">
                {sponsors.map((sponsor, index) => (
                  <div key={index} className="rounded-lg border border-gray-200 p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-medium text-gray-900">Sponsor {index + 1}</h3>
                      {sponsors.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeSponsor(index)}
                          className="inline-flex items-center rounded-md border border-transparent bg-red-100 px-3 py-2 text-sm font-medium leading-4 text-red-700 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                        >
                          <svg className="-ml-0.5 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                          </svg>
                          Remove
                        </button>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <div>
                        <label htmlFor={`sponsor-name-${index}`} className="block text-sm font-medium text-gray-700">
                          Sponsor Name <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id={`sponsor-name-${index}`}
                          value={sponsor.name}
                          onChange={(e) => handleSponsorChange(index, 'name', e.target.value)}
                          required
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="e.g. Unity Bank"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor={`sponsor-website-${index}`} className="block text-sm font-medium text-gray-700">
                          Website
                        </label>
                        <input
                          type="url"
                          id={`sponsor-website-${index}`}
                          value={sponsor.website}
                          onChange={(e) => handleSponsorChange(index, 'website', e.target.value)}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="e.g. https://www.unitybank.ng"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex justify-end space-x-3">
              <Link
                href="/events"
                className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Cancel
              </Link>
              <button
                type="submit"
                disabled={loading}
                className={`rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                  loading ? 'opacity-75 cursor-not-allowed' : ''
                }`}
              >
                {loading ? (
                  <span className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Creating...
                  </span>
                ) : (
                  'Create Event'
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  )
}
