'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

export default function EventsList() {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [filter, setFilter] = useState({
    type: '',
    school: '',
    upcoming: true
  })
  
  // Mock data for events (would be fetched from API)
  const mockEvents = [
    {
      id: '1',
      title: 'USOSA Annual General Meeting 2025',
      description: 'Annual gathering of all Unity Schools alumni to discuss progress and plans for the association.',
      eventType: 'Conference',
      startDate: '2025-07-15T09:00:00.000Z',
      endDate: '2025-07-15T17:00:00.000Z',
      location: {
        venue: 'Transcorp Hilton',
        address: '1 Aguiyi Ironsi Street',
        city: 'Abuja',
        state: 'FCT',
        country: 'Nigeria',
        isVirtual: false
      },
      organizer: {
        id: '101',
        firstName: 'Ahmed',
        lastName: 'Ibrahim',
        email: 'ahmed.ibrahim@example.com'
      },
      isSchoolSpecific: false,
      registrationRequired: true,
      registrationDeadline: '2025-07-10T23:59:59.000Z',
      attendees: 156,
      capacity: 300,
      status: 'published',
      visibility: 'alumni_only',
      createdAt: '2025-03-01T10:30:00.000Z'
    },
    {
      id: '2',
      title: 'FGC Buni-Yadi Class of 2010 Reunion',
      description: 'Reunion event for the 2010 graduating class of Federal Government College, Buni-Yadi.',
      eventType: 'Reunion',
      startDate: '2025-05-20T14:00:00.000Z',
      endDate: '2025-05-20T22:00:00.000Z',
      location: {
        venue: 'Sheraton Hotel',
        address: '30 Lateef Jakande Road',
        city: 'Lagos',
        state: 'Lagos',
        country: 'Nigeria',
        isVirtual: false
      },
      organizer: {
        id: '102',
        firstName: 'Fatima',
        lastName: 'Mohammed',
        email: 'fatima.mohammed@example.com'
      },
      schoolId: {
        id: '1',
        name: 'Federal Government College, Buni-Yadi',
        shortName: 'FGC Buni-Yadi'
      },
      isSchoolSpecific: true,
      registrationRequired: true,
      registrationDeadline: '2025-05-15T23:59:59.000Z',
      attendees: 42,
      capacity: 100,
      status: 'published',
      visibility: 'school_alumni_only',
      createdAt: '2025-02-15T08:45:00.000Z'
    },
    {
      id: '3',
      title: 'Career Development Workshop',
      description: 'Workshop focused on career advancement strategies for Unity Schools alumni.',
      eventType: 'Workshop',
      startDate: '2025-04-10T10:00:00.000Z',
      endDate: '2025-04-10T16:00:00.000Z',
      location: {
        venue: 'Virtual Event',
        address: 'Online',
        city: 'N/A',
        state: 'N/A',
        country: 'Nigeria',
        isVirtual: true,
        virtualLink: 'https://zoom.us/j/example'
      },
      organizer: {
        id: '103',
        firstName: 'John',
        lastName: 'Okafor',
        email: 'john.okafor@example.com'
      },
      isSchoolSpecific: false,
      registrationRequired: true,
      registrationDeadline: '2025-04-08T23:59:59.000Z',
      attendees: 215,
      capacity: 500,
      status: 'published',
      visibility: 'public',
      createdAt: '2025-03-05T14:20:00.000Z'
    },
    {
      id: '4',
      title: 'Kings College Lagos Alumni Dinner',
      description: 'Annual dinner for Kings College Lagos alumni to network and celebrate achievements.',
      eventType: 'Social',
      startDate: '2025-06-05T18:00:00.000Z',
      endDate: '2025-06-05T23:00:00.000Z',
      location: {
        venue: 'Eko Hotel & Suites',
        address: 'Victoria Island',
        city: 'Lagos',
        state: 'Lagos',
        country: 'Nigeria',
        isVirtual: false
      },
      organizer: {
        id: '104',
        firstName: 'Emmanuel',
        lastName: 'Adebayo',
        email: 'emmanuel.adebayo@example.com'
      },
      schoolId: {
        id: '4',
        name: 'King\'s College, Lagos',
        shortName: 'KC Lagos'
      },
      isSchoolSpecific: true,
      registrationRequired: true,
      registrationDeadline: '2025-05-30T23:59:59.000Z',
      registrationFee: {
        amount: 15000,
        currency: 'NGN'
      },
      attendees: 87,
      capacity: 200,
      status: 'published',
      visibility: 'school_alumni_only',
      createdAt: '2025-02-28T09:10:00.000Z'
    },
    {
      id: '5',
      title: 'USOSA Leadership Seminar',
      description: 'Seminar on leadership skills and community development for Unity Schools alumni.',
      eventType: 'Seminar',
      startDate: '2025-08-12T09:30:00.000Z',
      endDate: '2025-08-12T15:30:00.000Z',
      location: {
        venue: 'Radisson Blu',
        address: 'Isaac John Street, Ikeja GRA',
        city: 'Lagos',
        state: 'Lagos',
        country: 'Nigeria',
        isVirtual: false
      },
      organizer: {
        id: '105',
        firstName: 'Amina',
        lastName: 'Yusuf',
        email: 'amina.yusuf@example.com'
      },
      isSchoolSpecific: false,
      registrationRequired: true,
      registrationDeadline: '2025-08-05T23:59:59.000Z',
      attendees: 0,
      capacity: 150,
      status: 'draft',
      visibility: 'alumni_only',
      createdAt: '2025-03-10T11:25:00.000Z'
    }
  ]
  
  useEffect(() => {
    // Simulate API call to fetch events
    const fetchEvents = async () => {
      try {
        setLoading(true)
        
        // This would be replaced with actual API call
        // const response = await fetch(`/api/events?type=${filter.type}&school=${filter.school}&upcoming=${filter.upcoming}`)
        // const data = await response.json()
        // setEvents(data.events)
        
        // Using mock data for now
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        // Filter mock data based on filter state
        let filteredEvents = [...mockEvents]
        
        if (filter.type) {
          filteredEvents = filteredEvents.filter(event => event.eventType === filter.type)
        }
        
        if (filter.school) {
          filteredEvents = filteredEvents.filter(event => 
            event.schoolId && event.schoolId.id === filter.school
          )
        }
        
        if (filter.upcoming) {
          filteredEvents = filteredEvents.filter(event => 
            new Date(event.startDate) > new Date() && event.status === 'published'
          )
        } else {
          filteredEvents = filteredEvents.filter(event => event.status === 'published')
        }
        
        setEvents(filteredEvents)
      } catch (err) {
        console.error('Error fetching events:', err)
        setError('Failed to load events. Please try again later.')
      } finally {
        setLoading(false)
      }
    }
    
    fetchEvents()
  }, [filter])
  
  const handleFilterChange = (e) => {
    const { name, value, type, checked } = e.target
    setFilter(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
  }
  
  // Format date for display
  const formatDate = (dateString) => {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }
  
  // Format time for display
  const formatTime = (dateString) => {
    const options = { hour: '2-digit', minute: '2-digit' }
    return new Date(dateString).toLocaleTimeString(undefined, options)
  }
  
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-900">USOSA Events</h1>
          <p className="mt-2 text-gray-600">Discover upcoming reunions, seminars, and networking events</p>
        </div>
        
        <div className="mb-8">
          <div className="rounded-lg bg-gradient-to-r from-blue-600 to-indigo-700 p-6 text-white shadow-md">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="text-2xl font-bold">Find Your Next Event</h2>
                <p className="mt-2 max-w-2xl">
                  Connect with fellow alumni through our various events. Register for upcoming reunions, seminars, and networking opportunities.
                </p>
              </div>
              <div className="mt-4 md:mt-0">
                <Link 
                  href="/events/create" 
                  className="rounded-md bg-white px-4 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50"
                >
                  Create Event
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-8">
          <div className="rounded-lg bg-white p-4 shadow-md">
            <h3 className="mb-4 text-lg font-medium text-gray-900">Filter Events</h3>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
              <div>
                <label htmlFor="type" className="block text-sm font-medium text-gray-700">
                  Event Type
                </label>
                <select
                  id="type"
                  name="type"
                  value={filter.type}
                  onChange={handleFilterChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="">All Types</option>
                  <option value="Reunion">Reunion</option>
                  <option value="Seminar">Seminar</option>
                  <option value="Workshop">Workshop</option>
                  <option value="Conference">Conference</option>
                  <option value="Networking">Networking</option>
                  <option value="Social">Social</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="school" className="block text-sm font-medium text-gray-700">
                  School
                </label>
                <select
                  id="school"
                  name="school"
                  value={filter.school}
                  onChange={handleFilterChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="">All Schools</option>
                  <option value="1">FGC Buni-Yadi</option>
                  <option value="2">FGGC Potiskum</option>
                  <option value="3">FGC Jos</option>
                  <option value="4">KC Lagos</option>
                  <option value="5">QC Lagos</option>
                </select>
              </div>
              
              <div className="flex items-center">
                <input
                  id="upcoming"
                  name="upcoming"
                  type="checkbox"
                  checked={filter.upcoming}
                  onChange={handleFilterChange}
                  className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="upcoming" className="ml-2 block text-sm text-gray-700">
                  Show only upcoming events
                </label>
              </div>
              
              <div className="flex items-end">
                <button
                  onClick={() => setFilter({ type: '', school: '', upcoming: true })}
                  className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Reset Filters
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {loading ? (
          <div className="flex min-h-[400px] items-center justify-center">
            <div className="text-center">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
              <p className="mt-2 text-gray-600">Loading events...</p>
            </div>
          </div>
        ) : error ? (
          <div className="rounded-lg bg-white p-8 text-center shadow-md">
            <div className="mb-4 rounded-full bg-red-100 p-3 inline-block">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="text-red-600">{error}</p>
            <button 
              onClick={() => window.location.reload()}
              className="mt-4 rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              Try Again
            </button>
          </div>
        ) : events.length === 0 ? (
          <div className="rounded-lg bg-white p-8 text-center shadow-md">
            <div className="mb-4 rounded-full bg-gray-100 p-3 inline-block">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-gray-600">No events found matching your criteria.</p>
            <button 
              onClick={() => setFilter({ type: '', school: '', upcoming: true })}
              className="mt-4 rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {events.map(event => (
              <Link key={event.id} href={`/events/${event.id}`} className="block">
                <div className="h-full rounded-lg bg-white shadow-md transition-transform hover:scale-[1.02]">
                  <div className="h-48 overflow-hidden rounded-t-lg bg-gray-200">
                    {event.banner ? (
                      <img 
                        src={event.banner} 
                        alt={event.title} 
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-gradient-to-r from-blue-500 to-indigo-600">
                        <div className="text-center text-white">
                          <div className="mb-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                          </div>
                          <p className="text-lg font-semibold">{event.eventType}</p>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="p-6">
                    <div className="mb-2 flex items-center">
                      <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                        event.isSchoolSpecific
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {event.isSchoolSpecific ? 'School Event' : 'USOSA Event'}
                      </span>
                      
                      {event.location.isVirtual && (
                        <span className="ml-2 inline-flex rounded-full bg-green-100 px-2 text-xs font-semibold leading-5 text-green-800">
                          Virtual
                        </span>
                      )}
                    </div>
                    
                    <h3 className="mb-2 text-xl font-bold text-gray-900 line-clamp-2">{event.title}</h3>
                    
                    <p className="mb-4 text-sm text-gray-600 line-clamp-2">{event.description}</p>
                    
                    <div className="mb-4 space-y-2">
                      <div className="flex items-start">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mr-2 h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <span className="text-sm text-gray-700">
                          {formatDate(event.startDate)}
                        </span>
                      </div>
                      
                      <div className="flex items-start">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mr-2 h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span className="text-sm text-gray-700">
                          {formatTime(event.startDate)} - {formatTime(event.endDate)}
                        </span>
                      </div>
                      
                      <div className="flex items-start">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mr-2 h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        <span className="text-sm text-gray-700">
                          {event.location.venue}, {event.location.city}
                        </span>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex items-center justify-between">
                      <div className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mr-1 h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                        <span className="text-sm text-gray-700">
                          {event.attendees} {event.capacity ? `/ ${event.capacity}` : ''} attendees
                        </span>
                      </div>
                      
                      {event.registrationFee && event.registrationFee.amount > 0 && (
                        <span className="text-sm font-medium text-gray-900">
                          {event.registrationFee.currency} {event.registrationFee.amount.toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
