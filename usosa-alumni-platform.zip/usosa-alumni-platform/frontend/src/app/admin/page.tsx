'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('schools')
  const [schools, setSchools] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  // Mock data for schools (would be fetched from API)
  const mockSchools = [
    {
      id: '1',
      name: 'Federal Government College, Buni-Yadi',
      shortName: 'FGC Buni-Yadi',
      type: 'Federal Government College',
      gender: 'Mixed',
      location: {
        city: 'Buni-Yadi',
        state: 'Yobe',
        region: 'North East'
      },
      foundedYear: 1996,
      alumniCount: 3245,
      adminUsers: [
        {
          id: '101',
          firstName: 'Ahmed',
          lastName: 'Ibrahim',
          email: 'ahmed.ibrahim@example.com'
        }
      ],
      isActive: true,
      createdAt: '2025-01-15T10:30:00.000Z'
    },
    {
      id: '2',
      name: 'Federal Government Girls College, Potiskum',
      shortName: 'FGGC Potiskum',
      type: 'Federal Government Girls College',
      gender: 'Female',
      location: {
        city: 'Potiskum',
        state: 'Yobe',
        region: 'North East'
      },
      foundedYear: 1994,
      alumniCount: 2876,
      adminUsers: [
        {
          id: '102',
          firstName: 'Fatima',
          lastName: 'Mohammed',
          email: 'fatima.mohammed@example.com'
        }
      ],
      isActive: true,
      createdAt: '2025-01-15T11:45:00.000Z'
    },
    {
      id: '3',
      name: 'Federal Government College, Jos',
      shortName: 'FGC Jos',
      type: 'Federal Government College',
      gender: 'Mixed',
      location: {
        city: 'Jos',
        state: 'Plateau',
        region: 'North Central'
      },
      foundedYear: 1973,
      alumniCount: 8765,
      adminUsers: [
        {
          id: '103',
          firstName: 'John',
          lastName: 'Okafor',
          email: 'john.okafor@example.com'
        }
      ],
      isActive: true,
      createdAt: '2025-01-16T09:15:00.000Z'
    },
    {
      id: '4',
      name: 'King\'s College, Lagos',
      shortName: 'KC Lagos',
      type: 'Kings College',
      gender: 'Male',
      location: {
        city: 'Lagos',
        state: 'Lagos',
        region: 'South West'
      },
      foundedYear: 1909,
      alumniCount: 12543,
      adminUsers: [
        {
          id: '104',
          firstName: 'Emmanuel',
          lastName: 'Adebayo',
          email: 'emmanuel.adebayo@example.com'
        }
      ],
      isActive: true,
      createdAt: '2025-01-16T14:20:00.000Z'
    },
    {
      id: '5',
      name: 'Queen\'s College, Lagos',
      shortName: 'QC Lagos',
      type: 'Queens College',
      gender: 'Female',
      location: {
        city: 'Lagos',
        state: 'Lagos',
        region: 'South West'
      },
      foundedYear: 1927,
      alumniCount: 11876,
      adminUsers: [
        {
          id: '105',
          firstName: 'Amina',
          lastName: 'Yusuf',
          email: 'amina.yusuf@example.com'
        }
      ],
      isActive: true,
      createdAt: '2025-01-17T08:45:00.000Z'
    }
  ]
  
  useEffect(() => {
    // Simulate API call to fetch schools
    const fetchSchools = async () => {
      try {
        setLoading(true)
        
        // This would be replaced with actual API call
        // const response = await fetch('/api/admin/schools')
        // const data = await response.json()
        // setSchools(data.schools)
        
        // Using mock data for now
        await new Promise(resolve => setTimeout(resolve, 1000))
        setSchools(mockSchools)
      } catch (err) {
        console.error('Error fetching schools:', err)
        setError('Failed to load schools. Please try again later.')
      } finally {
        setLoading(false)
      }
    }
    
    if (activeTab === 'schools') {
      fetchSchools()
    }
  }, [activeTab])
  
  // Format date for display
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 justify-between">
            <div className="flex">
              <div className="flex flex-shrink-0 items-center">
                <h1 className="text-xl font-bold text-blue-600">USOSA Admin</h1>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className={`inline-flex items-center border-b-2 px-1 pt-1 text-sm font-medium ${
                    activeTab === 'dashboard'
                      ? 'border-blue-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  }`}
                >
                  Dashboard
                </button>
                <button
                  onClick={() => setActiveTab('schools')}
                  className={`inline-flex items-center border-b-2 px-1 pt-1 text-sm font-medium ${
                    activeTab === 'schools'
                      ? 'border-blue-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  }`}
                >
                  Schools
                </button>
                <button
                  onClick={() => setActiveTab('users')}
                  className={`inline-flex items-center border-b-2 px-1 pt-1 text-sm font-medium ${
                    activeTab === 'users'
                      ? 'border-blue-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  }`}
                >
                  Users
                </button>
                <button
                  onClick={() => setActiveTab('forums')}
                  className={`inline-flex items-center border-b-2 px-1 pt-1 text-sm font-medium ${
                    activeTab === 'forums'
                      ? 'border-blue-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  }`}
                >
                  Forums
                </button>
                <button
                  onClick={() => setActiveTab('events')}
                  className={`inline-flex items-center border-b-2 px-1 pt-1 text-sm font-medium ${
                    activeTab === 'events'
                      ? 'border-blue-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  }`}
                >
                  Events
                </button>
              </div>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:items-center">
              <Link
                href="/profile"
                className="rounded-full bg-white p-1 text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                <span className="sr-only">View profile</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'schools' && (
          <div>
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Manage Schools</h2>
              <Link
                href="/admin/schools/new"
                className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
              >
                Add New School
              </Link>
            </div>
            
            {loading ? (
              <div className="rounded-lg bg-white p-8 text-center shadow-md">
                <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
                <p className="mt-2 text-gray-600">Loading schools...</p>
              </div>
            ) : error ? (
              <div className="rounded-lg bg-white p-8 text-center shadow-md">
                <div className="mb-4 rounded-full bg-red-100 p-3 inline-block">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <p className="text-red-600">{error}</p>
                <button 
                  onClick={() => window.location.reload()}
                  className="mt-4 rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
                >
                  Try Again
                </button>
              </div>
            ) : (
              <div className="overflow-hidden rounded-lg bg-white shadow">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                          School Name
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                          Type
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                          Location
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                          Alumni
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                          Created
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                          Status
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium uppercase tracking-wider text-gray-500">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 bg-white">
                      {schools.map(school => (
                        <tr key={school.id} className="hover:bg-gray-50">
                          <td className="whitespace-nowrap px-6 py-4">
                            <div className="flex items-center">
                              <div className="h-10 w-10 flex-shrink-0">
                                <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                  <span className="text-blue-600 font-semibold text-sm">
                                    {school.shortName.split(' ').map(word => word[0]).join('')}
                                  </span>
                                </div>
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{school.name}</div>
                                <div className="text-sm text-gray-500">{school.shortName}</div>
                              </div>
                            </div>
                          </td>
                          <td className="whitespace-nowrap px-6 py-4">
                            <div className="text-sm text-gray-900">{school.type}</div>
                            <div className="text-sm text-gray-500">{school.gender}</div>
                          </td>
                          <td className="whitespace-nowrap px-6 py-4">
                            <div className="text-sm text-gray-900">{school.location.city}, {school.location.state}</div>
                            <div className="text-sm text-gray-500">{school.location.region}</div>
                          </td>
                          <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
                            {school.alumniCount.toLocaleString()}
                          </td>
                          <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
                            {formatDate(school.createdAt)}
                          </td>
                          <td className="whitespace-nowrap px-6 py-4">
                            <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                              school.isActive
                                ? 'bg-green-100 text-green-800'
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {school.isActive ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td className="whitespace-nowrap px-6 py-4 text-right text-sm font-medium">
                            <div className="flex justify-end space-x-2">
                              <Link
                                href={`/admin/schools/${school.id}`}
                                className="text-blue-600 hover:text-blue-900"
                              >
                                View
                              </Link>
                              <Link
                                href={`/admin/schools/${school.id}/edit`}
                                className="text-indigo-600 hover:text-indigo-900"
                              >
                                Edit
                              </Link>
                              <button
                                className="text-red-600 hover:text-red-900"
                                onClick={() => {
                                  if (window.confirm('Are you sure you want to delete this school?')) {
                                    // Delete school logic would go here
                                    console.log('Delete school:', school.id)
                                  }
                                }}
                              >
                                Delete
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'dashboard' && (
          <div className="rounded-lg bg-white p-8 shadow-md">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Dashboard</h2>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-lg bg-white p-6 shadow-md border border-gray-200">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-blue-500 p-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Total Schools</dt>
                      <dd className="text-3xl font-semibold text-gray-900">42</dd>
                    </dl>
                  </div>
                </div>
              </div>
              
              <div className="rounded-lg bg-white p-6 shadow-md border border-gray-200">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-green-500 p-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Total Alumni</dt>
                      <dd className="text-3xl font-semibold text-gray-900">125,432</dd>
                    </dl>
                  </div>
                </div>
              </div>
              
              <div className="rounded-lg bg-white p-6 shadow-md border border-gray-200">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-purple-500 p-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Forum Posts</dt>
                      <dd className="text-3xl font-semibold text-gray-900">8,642</dd>
                    </dl>
                  </div>
                </div>
              </div>
              
              <div className="rounded-lg bg-white p-6 shadow-md border border-gray-200">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-yellow-500 p-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Upcoming Events</dt>
                      <dd className="text-3xl font-semibold text-gray-900">12</dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {(activeTab === 'users' || activeTab === 'forums' || activeTab === 'events') && (
          <div className="rounded-lg bg-white p-8 text-center shadow-md">
            <div className="mb-4 rounded-full bg-blue-100 p-3 inline-block">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900">Coming Soon</h3>
            <p className="mt-2 text-gray-600">
              This section is under development and will be available soon.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
